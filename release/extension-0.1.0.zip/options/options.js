"use strict";
(() => {
  // src/shared/messages.ts
  async function request(type, payload) {
    const response = await chrome.runtime.sendMessage({
      type,
      payload
    });
    if (!response?.ok)
      throw new Error(
        response?.error ?? "The extension background worker is unavailable."
      );
    return response.value;
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : "An unexpected extension error occurred.";
  }

  // src/shared/context.ts
  var GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  // src/shared/settings.ts
  function validateSettings(value) {
    if (!value || typeof value !== "object" || !("tenantId" in value) || typeof value.tenantId !== "string" || !GUID.test(value.tenantId.trim()) || !("clientId" in value) || typeof value.clientId !== "string" || !GUID.test(value.clientId.trim()) || !("auditEnabled" in value) || typeof value.auditEnabled !== "boolean")
      throw new Error(
        "Configure valid tenant and client GUIDs in Options first."
      );
    return {
      tenantId: value.tenantId.trim().toLowerCase(),
      clientId: value.clientId.trim().toLowerCase(),
      auditEnabled: value.auditEnabled
    };
  }
  async function readSettings() {
    const stored = await chrome.storage.sync.get("settings");
    return validateSettings(stored.settings);
  }

  // src/options/options.ts
  function element(id, type) {
    const node = document.getElementById(id);
    if (!(node instanceof type))
      throw new Error(`Missing options element: ${id}`);
    return node;
  }
  var tenant = element("tenant", HTMLInputElement);
  var client = element("client", HTMLInputElement);
  var audit = element("audit", HTMLInputElement);
  var status = element("status", HTMLParagraphElement);
  var form = element("settings", HTMLFormElement);
  element("redirect", HTMLElement).textContent = chrome.identity.getRedirectURL();
  function setStatus(text, error = false) {
    status.textContent = text;
    status.classList.toggle("error", error);
  }
  async function save() {
    const settings = validateSettings({
      tenantId: tenant.value,
      clientId: client.value,
      auditEnabled: audit.checked
    });
    const stored = await chrome.storage.sync.get("settings");
    if (!stored.settings || JSON.stringify(stored.settings) !== JSON.stringify(settings)) {
      await request("signOut", void 0);
      await chrome.storage.sync.set({ settings });
    }
  }
  async function run(operation) {
    const buttons = form.querySelectorAll("button");
    buttons.forEach((button) => button.disabled = true);
    try {
      await operation();
    } catch (error) {
      setStatus(errorMessage(error), true);
    } finally {
      buttons.forEach((button) => button.disabled = false);
    }
  }
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    void run(async () => {
      await save();
      setStatus("Settings saved. Sign in from the panel or test sign-in here.");
    });
  });
  element("test", HTMLButtonElement).addEventListener("click", () => {
    void run(async () => {
      await save();
      setStatus("Complete sign-in in the Microsoft window...");
      await request("signIn", void 0);
      setStatus(
        "Sign-in succeeded. Open the panel on an Entra Members or Groups blade."
      );
    });
  });
  element("signout", HTMLButtonElement).addEventListener("click", () => {
    void run(async () => {
      await request("signOut", void 0);
      setStatus(
        "Extension session cleared. Your Microsoft browser session is unchanged."
      );
    });
  });
  void readSettings().then(
    (settings) => {
      tenant.value = settings.tenantId;
      client.value = settings.clientId;
      audit.checked = settings.auditEnabled;
    },
    (error) => setStatus(errorMessage(error))
  );
})();
//# sourceMappingURL=options.js.map
