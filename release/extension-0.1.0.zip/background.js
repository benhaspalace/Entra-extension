"use strict";
(() => {
  // src/shared/pkce.ts
  function base64Url(bytes) {
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  async function createPkce() {
    const verifier = base64Url(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = base64Url(
      new Uint8Array(
        await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))
      )
    );
    return {
      verifier,
      challenge,
      state: base64Url(crypto.getRandomValues(new Uint8Array(32)))
    };
  }
  function authorizationCode(callback, redirectUri, expectedState) {
    const result = new URL(callback);
    const redirect = new URL(redirectUri);
    if (result.origin !== redirect.origin || result.pathname !== redirect.pathname || result.searchParams.get("state") !== expectedState)
      throw new Error("Sign-in redirect or state validation failed.");
    if (result.searchParams.has("error"))
      throw new Error("Microsoft sign-in was cancelled or denied. Try again.");
    const code = result.searchParams.get("code");
    if (!code)
      throw new Error("Microsoft sign-in did not return an authorization code.");
    return code;
  }

  // src/shared/context.ts
  var GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function parseUserProfile(href) {
    const parts = routeParts(href);
    if (!parts) return null;
    if (parts[0]?.toLowerCase() !== "view" || parts[1]?.toLowerCase() !== "microsoft_aad_usersandtenants" || parts[2]?.toLowerCase() !== "userprofilemenublade" || parts[3] !== "~" || !parts[4])
      return null;
    const keyIndex = parts.findIndex(
      (part, index) => index > 4 && part.toLowerCase() === "userid"
    );
    const id = parts[keyIndex + 1];
    return keyIndex >= 0 && id && GUID.test(id) ? id.toLowerCase() : null;
  }
  function routeParts(href) {
    let url;
    try {
      url = new URL(href);
    } catch {
      return null;
    }
    if (url.origin !== "https://entra.microsoft.com") return null;
    let hash = url.hash;
    for (let depth = 0; depth < 4; depth++) {
      try {
        const decoded = decodeURIComponent(hash);
        if (decoded === hash) break;
        hash = decoded;
      } catch {
        return null;
      }
    }
    return hash.replace(/^#/, "").split("/");
  }

  // src/shared/settings.ts
  function validateSettings(value) {
    if (!value || typeof value !== "object" || !("tenantId" in value) || typeof value.tenantId !== "string" || !GUID.test(value.tenantId.trim()) || !("clientId" in value) || typeof value.clientId !== "string" || !GUID.test(value.clientId.trim()) || !("auditEnabled" in value) || typeof value.auditEnabled !== "boolean")
      throw new Error(
        "Configure valid tenant and client GUIDs in Options first."
      );
    return {
      tenantId: value.tenantId.trim().toLowerCase(),
      clientId: value.clientId.trim().toLowerCase(),
      auditEnabled: value.auditEnabled
    };
  }
  async function readSettings() {
    const stored = await chrome.storage.sync.get("settings");
    return validateSettings(stored.settings);
  }
  function settingsKey(settings) {
    return `${settings.tenantId}:${settings.clientId}:${settings.auditEnabled}`;
  }
  function authScopes(settings) {
    return [
      "openid",
      "profile",
      "offline_access",
      "https://graph.microsoft.com/User.Read",
      "https://graph.microsoft.com/GroupMember.Read.All",
      "https://graph.microsoft.com/EntitlementManagement.Read.All",
      ...settings.auditEnabled ? ["https://graph.microsoft.com/AuditLog.Read.All"] : []
    ].join(" ");
  }

  // src/background/auth.ts
  var pending;
  var revision = 0;
  async function session() {
    const result = await chrome.storage.session.get("auth");
    return result.auth ?? null;
  }
  async function signOut() {
    revision++;
    await chrome.storage.session.clear();
    return { signedIn: false, sessionId: null };
  }
  async function authStatus() {
    const current = await session();
    if (!current) return { signedIn: false, sessionId: null };
    const settings = await readSettings();
    const signedIn = current.settingsKey === settingsKey(settings) && (current.expiresAt > Date.now() || !!current.refreshToken);
    return { signedIn, sessionId: signedIn ? current.sessionId : null };
  }
  async function exchange(settings, params, sessionId, currentRevision, previousRefreshToken = null) {
    const response = await fetch(
      `https://login.microsoftonline.com/${settings.tenantId}/oauth2/v2.0/token`,
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params,
        redirect: "error"
      }
    );
    if (!response.ok) {
      if (response.status === 400 || response.status === 401) await signOut();
      throw new Error(
        `Sign-in token exchange failed (${response.status}). Sign in again; verify the SPA redirect URI, consent and tenant settings.`
      );
    }
    const body = await response.json();
    if (!body || typeof body !== "object" || !("access_token" in body) || typeof body.access_token !== "string" || !("expires_in" in body) || !Number.isFinite(Number(body.expires_in)) || Number(body.expires_in) <= 0 || !("token_type" in body) || typeof body.token_type !== "string" || body.token_type.toLowerCase() !== "bearer")
      throw new Error(
        "Microsoft returned an invalid token response. Sign in again."
      );
    if (currentRevision !== revision || settingsKey(await readSettings()) !== settingsKey(settings))
      throw new Error("Settings or sign-in state changed. Sign in again.");
    const token = {
      accessToken: body.access_token,
      refreshToken: "refresh_token" in body && typeof body.refresh_token === "string" ? body.refresh_token : previousRefreshToken,
      expiresAt: Date.now() + Number(body.expires_in) * 1e3,
      settingsKey: settingsKey(settings),
      sessionId
    };
    await chrome.storage.session.set({ auth: token });
    if (currentRevision !== revision) {
      await chrome.storage.session.remove("auth");
      throw new Error("Sign-in state changed. Sign in again.");
    }
    return token;
  }
  async function interactive() {
    const settings = await readSettings();
    const currentRevision = revision;
    const pkce = await createPkce();
    const redirect = chrome.identity.getRedirectURL();
    const authorize = new URL(
      `https://login.microsoftonline.com/${settings.tenantId}/oauth2/v2.0/authorize`
    );
    authorize.search = new URLSearchParams({
      client_id: settings.clientId,
      response_type: "code",
      redirect_uri: redirect,
      response_mode: "query",
      scope: authScopes(settings),
      code_challenge: pkce.challenge,
      code_challenge_method: "S256",
      state: pkce.state,
      prompt: "select_account"
    }).toString();
    const callback = await chrome.identity.launchWebAuthFlow({
      url: authorize.href,
      interactive: true
    });
    if (!callback) throw new Error("Microsoft sign-in was cancelled.");
    const code = authorizationCode(callback, redirect, pkce.state);
    await chrome.storage.session.remove("packageCache");
    return exchange(
      settings,
      new URLSearchParams({
        client_id: settings.clientId,
        grant_type: "authorization_code",
        code,
        code_verifier: pkce.verifier,
        redirect_uri: redirect,
        scope: authScopes(settings)
      }),
      crypto.randomUUID(),
      currentRevision
    );
  }
  async function exclusive(operation) {
    if (pending) return pending;
    pending = operation();
    try {
      return await pending;
    } finally {
      pending = void 0;
    }
  }
  async function signIn() {
    const token = await exclusive(interactive);
    return { signedIn: true, sessionId: token.sessionId };
  }
  async function getToken(forceRefresh) {
    if (pending) return (await pending).accessToken;
    const settings = await readSettings();
    const cached = await session();
    if (!cached || cached.settingsKey !== settingsKey(settings))
      throw new Error("Sign in to Microsoft Entra to continue.");
    if (!forceRefresh && cached.expiresAt > Date.now() + 6e4)
      return cached.accessToken;
    const token = await exclusive(async () => {
      const settings2 = await readSettings();
      const currentRevision = revision;
      const current = await session();
      if (!current || current.settingsKey !== settingsKey(settings2))
        throw new Error("Sign in to Microsoft Entra to continue.");
      if (!forceRefresh && current.expiresAt > Date.now() + 6e4)
        return current;
      if (!current.refreshToken) {
        await signOut();
        throw new Error("Your session expired. Sign in again.");
      }
      return exchange(
        settings2,
        new URLSearchParams({
          client_id: settings2.clientId,
          grant_type: "refresh_token",
          refresh_token: current.refreshToken,
          scope: authScopes(settings2)
        }),
        current.sessionId,
        currentRevision,
        current.refreshToken
      );
    });
    return token.accessToken;
  }

  // src/shared/messages.ts
  function errorMessage(error) {
    return error instanceof Error ? error.message : "An unexpected extension error occurred.";
  }

  // src/shared/graph.ts
  var ROOT = "https://graph.microsoft.com/v1.0";
  var GraphError = class extends Error {
    constructor(status, code, scope) {
      super(
        status === 401 ? "Your session expired. Sign in again." : status === 403 ? `Missing permission or directory role: ${scope}. Grant admin consent and verify your directory role.` : `Microsoft Graph request failed (${status}, ${code}).`
      );
      this.status = status;
      this.code = code;
      this.scope = scope;
      this.name = "GraphError";
    }
    status;
    code;
    scope;
  };
  function graphUrl(path) {
    const url = new URL(path.startsWith("/") ? `${ROOT}${path}` : path);
    if (url.origin !== "https://graph.microsoft.com" || !url.pathname.startsWith("/v1.0/") || url.username || url.password || url.hash)
      throw new Error("Rejected a Graph URL outside the Graph v1.0 endpoint.");
    return url.href;
  }
  function retryDelay(value, attempt, now = Date.now()) {
    let delay = Math.min(1e3 * 2 ** attempt, 3e4);
    if (value) {
      const seconds = Number(value);
      if (Number.isFinite(seconds) && seconds >= 0) delay = seconds * 1e3;
      else {
        const date = Date.parse(value);
        if (Number.isFinite(date)) delay = Math.max(0, date - now);
      }
    }
    if (delay > 6e4)
      throw new Error(
        "Microsoft Graph throttling requires a wait longer than 60 seconds. Try again later."
      );
    return delay;
  }
  function createGraphClient(getToken2, fetcher = fetch, sleep = (ms, signal) => new Promise((resolve, reject) => {
    signal?.throwIfAborted();
    const onAbort = () => {
      clearTimeout(timer);
      reject(signal?.reason);
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  })) {
    async function graphFetch(path, scope, signal) {
      const url = graphUrl(path);
      signal?.throwIfAborted();
      let refreshed = false;
      let token = await getToken2(false);
      let retries = 0;
      while (true) {
        signal?.throwIfAborted();
        const response = await fetcher(url, {
          headers: {
            Authorization: `Bearer ${token}`,
            ...new URL(url).pathname.includes("/microsoft.graph.") ? { ConsistencyLevel: "eventual" } : {}
          },
          redirect: "error",
          ...signal ? { signal } : {}
        });
        if (response.status === 401 && !refreshed) {
          refreshed = true;
          token = await getToken2(true);
          continue;
        }
        if ((response.status === 429 || response.status === 503) && retries < 4) {
          await sleep(
            retryDelay(response.headers.get("Retry-After"), retries++),
            signal
          );
          continue;
        }
        if (!response.ok) {
          const body = await response.json().catch(() => null);
          const code = body && typeof body === "object" && "error" in body && body.error && typeof body.error === "object" && "code" in body.error && typeof body.error.code === "string" ? body.error.code : "RequestFailed";
          throw new GraphError(response.status, code, scope);
        }
        return await response.json();
      }
    }
    async function list(path, scope, signal) {
      const values = [];
      const visited = /* @__PURE__ */ new Set();
      let next = path;
      while (next) {
        const url = graphUrl(next);
        if (visited.has(url))
          throw new Error("Microsoft Graph returned a paging loop.");
        visited.add(url);
        const page = await graphFetch(url, scope, signal);
        if (!Array.isArray(page.value) || page["@odata.nextLink"] !== void 0 && typeof page["@odata.nextLink"] !== "string")
          throw new Error("Microsoft Graph returned an invalid list response.");
        values.push(...page.value);
        next = page["@odata.nextLink"];
      }
      return values;
    }
    return { graphFetch, list };
  }

  // src/shared/packages.ts
  var ENTITLEMENTS = "/identityGovernance/entitlementManagement";
  var PACKAGE_SCOPE = "EntitlementManagement.Read.All";
  async function loadPackages(graph, sessionId, signal) {
    const stored = await chrome.storage.session.get("packageCache");
    const cache = stored.packageCache;
    if (cache?.sessionId === sessionId && cache.expiresAt > Date.now())
      return cache.packages;
    const packages = await graph.list(
      `${ENTITLEMENTS}/accessPackages?$expand=resourceRoleScopes($expand=role,scope)&$select=id,displayName`,
      PACKAGE_SCOPE,
      signal
    );
    const complete = await mapLimited(packages, 4, async (pkg) => {
      if (!pkg["resourceRoleScopes@odata.nextLink"]) return pkg;
      return {
        ...pkg,
        resourceRoleScopes: await graph.list(
          `${ENTITLEMENTS}/accessPackages/${encodeURIComponent(pkg.id)}/resourceRoleScopes?$expand=role,scope`,
          PACKAGE_SCOPE,
          signal
        )
      };
    });
    signal.throwIfAborted();
    const auth = await chrome.storage.session.get("auth");
    const current = auth.auth;
    if (current?.sessionId === sessionId) {
      try {
        await chrome.storage.session.set({
          packageCache: {
            sessionId,
            expiresAt: Date.now() + 15 * 6e4,
            packages: complete
          }
        });
      } catch {
        console.warn(
          "Access package cache could not be saved to session storage."
        );
      }
    }
    return complete;
  }
  async function mapLimited(items, concurrency, operation) {
    if (!Number.isInteger(concurrency) || concurrency < 1)
      throw new Error("Concurrency must be a positive integer.");
    const results = new Array(items.length);
    const pending2 = items.entries();
    await Promise.all(
      Array.from({ length: Math.min(concurrency, items.length) }, async () => {
        for (const [index, item] of pending2) {
          results[index] = await operation(item);
        }
      })
    );
    return results;
  }

  // src/background/accessPackages.ts
  async function loadUserAccessPackages(userId, graph, sessionId, signal) {
    const [packages, assignments] = await Promise.all([
      loadPackages(graph, sessionId, signal),
      graph.list(
        `${ENTITLEMENTS}/assignments?$filter=${encodeURIComponent(`target/objectId eq '${userId}'`)}&$expand=accessPackage($expand=catalog),assignmentPolicy,target`,
        PACKAGE_SCOPE,
        signal
      )
    ]);
    const byId = new Map(packages.map((pkg) => [pkg.id.toLowerCase(), pkg]));
    return {
      userId,
      displayName: assignments.find((assignment) => assignment.target?.displayName)?.target?.displayName ?? userId,
      assignments: assignments.map((assignment) => {
        const pkg = byId.get(assignment.accessPackage?.id.toLowerCase() ?? "");
        const resources = /* @__PURE__ */ new Map();
        for (const { scope } of pkg?.resourceRoleScopes ?? []) {
          if (!scope?.originId || !scope.originSystem) continue;
          resources.set(`${scope.originSystem}:${scope.originId}`.toLowerCase(), {
            id: scope.originId,
            name: scope.displayName ?? scope.originId,
            system: scope.originSystem
          });
        }
        return {
          ...assignment,
          resources: [...resources.values()]
        };
      })
    };
  }

  // src/background/index.ts
  async function configurePanel(tabId, href) {
    await chrome.sidePanel.setOptions({
      tabId,
      path: "sidepanel/index.html",
      enabled: href.startsWith("https://entra.microsoft.com/")
    });
  }
  async function initialize() {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    await chrome.sidePanel.setOptions({ enabled: false });
    const tabs = await chrome.tabs.query({});
    await Promise.all(
      tabs.map(
        (tab) => tab.id !== void 0 ? configurePanel(tab.id, tab.url ?? "") : Promise.resolve()
      )
    );
  }
  for (const event of [chrome.runtime.onInstalled, chrome.runtime.onStartup])
    event.addListener(() => {
      void initialize().catch(
        (error) => console.error(errorMessage(error))
      );
    });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (change.url)
      void configurePanel(tabId, change.url).catch(
        (error) => console.error(errorMessage(error))
      );
  });
  function isTrustedPage(sender) {
    return sender.id === chrome.runtime.id && (sender.url === chrome.runtime.getURL("sidepanel/index.html") || sender.url === chrome.runtime.getURL("options/index.html"));
  }
  function profileUser(sender) {
    if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || sender.tab?.id === void 0 || !sender.url?.startsWith("https://entra.microsoft.com/"))
      return null;
    return parseUserProfile(sender.tab.url ?? sender.url);
  }
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (!message || typeof message !== "object" || !("type" in message) || typeof message.type !== "string")
        return;
      if (message.type === "contextChanged") {
        if (sender.tab?.id !== void 0 && sender.url)
          void configurePanel(sender.tab.id, sender.url).catch(
            (error) => console.error(errorMessage(error))
          );
        sendResponse({ ok: true, value: null });
        return;
      }
      const contentRequest = message.type === "getUserAccessPackages" || message.type === "openSidePanel";
      const userId = contentRequest ? profileUser(sender) : null;
      if (contentRequest ? !userId : !isTrustedPage(sender)) return;
      const action = message;
      async function handle() {
        switch (action.type) {
          case "openSidePanel":
            if (sender.tab?.id === void 0)
              throw new Error("The Entra tab is unavailable.");
            await chrome.sidePanel.open({ tabId: sender.tab.id });
            return null;
          case "getUserAccessPackages": {
            if (!userId || typeof action.payload?.userId !== "string" || action.payload.userId.toLowerCase() !== userId)
              throw new Error("Invalid user access package request.");
            const auth = await authStatus();
            if (!auth.signedIn || !auth.sessionId)
              throw new Error(
                "Set your tenant and client IDs in Options, then sign in using the side panel."
              );
            const data = await loadUserAccessPackages(
              userId,
              createGraphClient(getToken),
              auth.sessionId,
              new AbortController().signal
            );
            const current = await authStatus();
            if (!current.signedIn || current.sessionId !== auth.sessionId)
              throw new Error("Sign-in state changed. Sign in again.");
            return data;
          }
          case "authStatus":
            return authStatus();
          case "signIn":
            return signIn();
          case "signOut":
            return signOut();
          case "getToken":
            if (typeof action.payload?.refresh !== "boolean")
              throw new Error("Invalid token request.");
            return getToken(action.payload.refresh);
          default:
            throw new Error("Unknown extension request.");
        }
      }
      void handle().then(
        (value) => sendResponse({ ok: true, value }),
        (error) => sendResponse({ ok: false, error: errorMessage(error) })
      );
      return true;
    }
  );
})();
//# sourceMappingURL=background.js.map
