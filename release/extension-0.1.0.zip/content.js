"use strict";
(() => {
  // src/shared/context.ts
  var GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function parseUserProfile(href) {
    const parts = routeParts(href);
    if (!parts) return null;
    if (parts[0]?.toLowerCase() !== "view" || parts[1]?.toLowerCase() !== "microsoft_aad_usersandtenants" || parts[2]?.toLowerCase() !== "userprofilemenublade" || parts[3] !== "~" || !parts[4])
      return null;
    const keyIndex = parts.findIndex(
      (part, index) => index > 4 && part.toLowerCase() === "userid"
    );
    const id = parts[keyIndex + 1];
    return keyIndex >= 0 && id && GUID.test(id) ? id.toLowerCase() : null;
  }
  function routeParts(href) {
    let url;
    try {
      url = new URL(href);
    } catch {
      return null;
    }
    if (url.origin !== "https://entra.microsoft.com") return null;
    let hash = url.hash;
    for (let depth = 0; depth < 4; depth++) {
      try {
        const decoded = decodeURIComponent(hash);
        if (decoded === hash) break;
        hash = decoded;
      } catch {
        return null;
      }
    }
    return hash.replace(/^#/, "").split("/");
  }

  // src/shared/governance.ts
  var ACTIVE_ASSIGNMENT_STATES = [
    "delivered",
    "partiallyDelivered",
    "delivering"
  ];
  function isActiveAssignment(state) {
    return ACTIVE_ASSIGNMENT_STATES.some((active) => active === state);
  }

  // src/shared/accessPackages.ts
  function groupAssignments(assignments) {
    const active = [];
    const inactive = [];
    for (const assignment of assignments) {
      (isActiveAssignment(assignment.state) ? active : inactive).push(assignment);
    }
    return { active, inactive };
  }
  function formatDate(value) {
    if (!value) return "Not provided";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "Invalid date" : date.toISOString();
  }
  function formatExpiration(schedule) {
    const expiration = schedule?.expiration;
    if (expiration?.type === "noExpiration") return "No expiration";
    if (expiration?.endDateTime) return formatDate(expiration.endDateTime);
    if (expiration?.duration)
      return `After ${expiration.duration} from ${formatDate(schedule?.startDateTime)}`;
    return "Not provided";
  }

  // src/shared/links.ts
  var PORTAL = "https://entra.microsoft.com/#view/";
  function packageLink(id) {
    return `${PORTAL}Microsoft_Azure_ELMAdmin/EntitlementMenuBlade/~/overview/entitlementId/${encodeURIComponent(id)}`;
  }
  function memberLink(kind, id) {
    return kind === "group" ? `${PORTAL}Microsoft_AAD_IAM/GroupDetailsMenuBlade/~/Overview/groupId/${encodeURIComponent(id)}` : `${PORTAL}Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/${encodeURIComponent(id)}`;
  }

  // src/shared/messages.ts
  async function request(type, payload) {
    const response = await chrome.runtime.sendMessage({
      type,
      payload
    });
    if (!response?.ok)
      throw new Error(
        response?.error ?? "The extension background worker is unavailable."
      );
    return response.value;
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : "An unexpected extension error occurred.";
  }

  // src/content/drawer.ts
  var STYLES = `
:host { all: initial; position: fixed; inset: 0 0 0 auto; width: min(520px, 100vw);
  z-index: 2147483647; color-scheme: light; }
* { box-sizing: border-box; }
section { height: 100%; padding: 20px; overflow: auto; background: #fff; color: #242424;
  box-shadow: -4px 0 20px #0004; font: 14px/1.5 system-ui, sans-serif; }
h1 { font-size: 20px; margin: 0 0 16px; } h2 { font-size: 18px; }
button { font: inherit; margin: 0 8px 8px 0; padding: 6px 10px; cursor: pointer; }
a { color: #005a9e; overflow-wrap: anywhere; }
ul { padding-left: 20px; } li { margin-bottom: 12px; }
p { margin: 4px 0; overflow-wrap: anywhere; } article { padding: 12px 0; border-bottom: 1px solid #ddd; }
[role="alert"] { color: #a4262c; } :focus-visible { outline: 2px solid #005a9e; outline-offset: 2px; }
`;
  function text(tag, value) {
    const node = document.createElement(tag);
    node.textContent = value;
    return node;
  }
  function link(label, href) {
    const node = document.createElement("a");
    node.textContent = label;
    node.href = href;
    node.target = "_blank";
    node.rel = "noopener noreferrer";
    return node;
  }
  function assignmentRow(assignment) {
    const row = document.createElement("article");
    const pkg = assignment.accessPackage;
    row.append(
      pkg ? link(pkg.displayName ?? pkg.id, packageLink(pkg.id)) : text("p", "Access package not provided"),
      text("p", `Catalog: ${pkg?.catalog?.displayName ?? "Not provided"}`),
      text(
        "p",
        `Policy: ${assignment.assignmentPolicy?.displayName ?? "Not provided"}`
      ),
      text("p", `State: ${assignment.state}`),
      text("p", `Start: ${formatDate(assignment.schedule?.startDateTime)}`),
      text("p", `Expiry: ${formatExpiration(assignment.schedule)}`),
      text("p", "Resources (current package configuration):")
    );
    const resources = document.createElement("ul");
    for (const resource of assignment.resources) {
      const item = document.createElement("li");
      item.append(
        resource.system.toLowerCase() === "aadgroup" ? link(resource.name, memberLink("group", resource.id)) : text("span", `${resource.name} (${resource.system})`)
      );
      resources.append(item);
    }
    row.append(
      resources.childElementCount ? resources : text("p", "No resources returned")
    );
    return row;
  }
  function openDrawer(userId, returnFocus) {
    const host = document.createElement("div");
    const shadow = host.attachShadow({ mode: "closed" });
    const style = text("style", STYLES);
    const panel = document.createElement("section");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "false");
    panel.setAttribute("aria-labelledby", "drawer-title");
    const title = text("h1", `Access packages \u2014 ${userId}`);
    title.id = "drawer-title";
    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "Close";
    const sidePanel = document.createElement("button");
    sidePanel.type = "button";
    sidePanel.textContent = "Open in side panel";
    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.textContent = "Refresh";
    const status = text("p", "");
    status.setAttribute("role", "status");
    const content = document.createElement("div");
    panel.append(title, closeButton, sidePanel, refresh, status, content);
    shadow.append(style, panel);
    document.body.append(host);
    let closed = false;
    let version = 0;
    function close() {
      closed = true;
      version++;
      host.remove();
      if (returnFocus.isConnected) returnFocus.focus();
    }
    function showError(error) {
      status.setAttribute("role", "alert");
      status.textContent = errorMessage(error);
    }
    async function load() {
      const current = ++version;
      refresh.disabled = true;
      content.replaceChildren();
      status.setAttribute("role", "status");
      status.textContent = "Loading access package assignments...";
      try {
        const data = await request("getUserAccessPackages", { userId });
        if (closed || current !== version) return;
        title.textContent = `Access packages \u2014 ${data.displayName}`;
        const groups = groupAssignments(data.assignments);
        for (const [label, assignments] of [
          ["Active", groups.active],
          ["Expired / failed", groups.inactive]
        ]) {
          content.append(text("h2", label));
          if (!assignments.length) content.append(text("p", "None"));
          for (const assignment of assignments)
            content.append(assignmentRow(assignment));
        }
        status.textContent = data.assignments.length ? `${data.assignments.length} assignments. Dates are UTC.` : "No access package assignments";
      } catch (error) {
        if (!closed && current === version) showError(error);
      } finally {
        if (!closed && current === version) refresh.disabled = false;
      }
    }
    closeButton.addEventListener("click", close);
    panel.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        close();
      }
    });
    sidePanel.addEventListener("click", () => {
      void request("openSidePanel", void 0).catch(showError);
    });
    refresh.addEventListener("click", () => void load());
    closeButton.focus();
    void load();
    return { close };
  }

  // src/content/menuLabels.ts
  var customSecurityAttributeLabels = ["Custom security attributes"];
  var accessPackagesLabel = "Access packages";

  // src/content/menu.ts
  var MENU_MARKER = '[data-entra-helper="access-packages"]';
  var ITEM_SELECTOR = '[role="listitem"], [role="treeitem"], [role="menuitem"], li';
  function* labelNodes(root, labels) {
    const document2 = root.ownerDocument ?? globalThis.document;
    const walker = document2.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      if (labels.includes(node.textContent?.trim() ?? "")) yield node;
    }
  }
  function findAnchorItem(root, labels = customSecurityAttributeLabels) {
    let last = null;
    let visible = null;
    for (const node of labelNodes(root, labels)) {
      const element = node.parentElement;
      if (element?.closest("[data-entra-helper]")) continue;
      const item = element?.closest(ITEM_SELECTOR);
      if (!item) continue;
      last = item;
      if (item.getClientRects().length > 0) visible = item;
    }
    const document2 = root.ownerDocument ?? globalThis.document;
    return visible ?? (document2.documentElement.getClientRects().length === 0 ? last : null);
  }
  function cloneMenuItem(anchor) {
    const clone = anchor.cloneNode(true);
    clone.querySelectorAll(
      "script, style, link, iframe, object, embed, img, input, select, textarea"
    ).forEach((node) => node.remove());
    for (const node of clone.querySelectorAll("a, button")) {
      const span = anchor.ownerDocument.createElement("span");
      for (const attribute of node.attributes)
        span.setAttribute(attribute.name, attribute.value);
      span.append(...node.childNodes);
      node.replaceWith(span);
    }
    for (const node of [clone, ...clone.querySelectorAll("*")]) {
      for (const attribute of [...node.attributes]) {
        if (/^on/i.test(attribute.name) || /^(id|href|xlink:href|src|srcset|target|style|tabindex|role|aria-.+|data-.+)$/i.test(
          attribute.name
        ))
          node.removeAttribute(attribute.name);
      }
      for (const name of [...node.classList]) {
        if (/(selected|active|current|focused)/i.test(name))
          node.classList.remove(name);
      }
    }
    const label = [...labelNodes(clone, customSecurityAttributeLabels)].at(
      -1
    )?.parentElement;
    const wrapper = label ?? clone;
    wrapper.textContent = accessPackagesLabel;
    const icons = [
      ...clone.querySelectorAll('svg, [class*="icon"], [class*="Icon"]')
    ].filter((node) => node !== wrapper && !node.contains(wrapper));
    const svg = anchor.ownerDocument.createElementNS(
      "http://www.w3.org/2000/svg",
      "svg"
    );
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "16");
    svg.setAttribute("height", "16");
    svg.setAttribute("aria-hidden", "true");
    const path = anchor.ownerDocument.createElementNS(
      "http://www.w3.org/2000/svg",
      "path"
    );
    path.setAttribute("fill", "currentColor");
    path.setAttribute("d", "M3 5h7l2 2h9v13H3V5zm2 4v9h14V9H5zm2 3h10v2H7v-2z");
    svg.append(path);
    const icon = icons[0];
    if (icon?.tagName.toLowerCase() === "svg") icon.replaceWith(svg);
    else if (icon) icon.replaceChildren(svg);
    else clone.prepend(svg);
    for (const extra of icons.slice(1)) {
      if (!icon?.contains(extra)) extra.remove();
    }
    clone.dataset.entraHelper = "access-packages";
    clone.setAttribute("role", anchor.getAttribute("role") ?? "menuitem");
    clone.setAttribute("tabindex", "0");
    clone.setAttribute("aria-label", accessPackagesLabel);
    return clone;
  }

  // src/content/profileMenu.ts
  function watchProfileMenu() {
    let userId = null;
    let observer;
    let timer;
    let lastInjection = 0;
    let drawer;
    function removeItems() {
      document.querySelectorAll(MENU_MARKER).forEach((node) => node.remove());
    }
    function inject() {
      lastInjection = Date.now();
      if (!userId || parseUserProfile(location.href) !== userId) return;
      const anchor = findAnchorItem(document.body);
      if (!anchor?.parentElement) {
        removeItems();
        return;
      }
      const items = [...document.querySelectorAll(MENU_MARKER)];
      const current = items.find((item2) => item2.nextElementSibling === anchor);
      for (const item2 of items) if (item2 !== current) item2.remove();
      if (current) return;
      const item = cloneMenuItem(anchor);
      function activate(event) {
        if (event.isTrusted === false) return;
        event.preventDefault();
        event.stopPropagation();
        if (!userId || parseUserProfile(location.href) !== userId) return;
        drawer?.close();
        drawer = openDrawer(userId, item);
      }
      item.addEventListener("click", activate);
      item.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") activate(event);
      });
      anchor.before(item);
    }
    function stop() {
      observer?.disconnect();
      observer = void 0;
      clearTimeout(timer);
      timer = void 0;
      removeItems();
      drawer?.close();
      drawer = void 0;
    }
    function update() {
      const next = parseUserProfile(location.href);
      if (next === userId) return;
      stop();
      userId = next;
      if (!userId) return;
      observer = new MutationObserver(() => {
        if (timer !== void 0) return;
        timer = setTimeout(
          () => {
            timer = void 0;
            inject();
          },
          Math.max(0, 250 - (Date.now() - lastInjection))
        );
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      inject();
    }
    return {
      update,
      dispose: () => {
        stop();
        userId = null;
      }
    };
  }

  // src/content/index.ts
  var previous = "";
  var profileMenu = watchProfileMenu();
  function watchLocation() {
    if (location.href === previous) return;
    previous = location.href;
    profileMenu.update();
    void chrome.runtime.sendMessage({ type: "contextChanged" }).catch(() => {
      console.warn(
        "Entra Admin Helper: reload the portal to reconnect the extension."
      );
    });
  }
  window.addEventListener("hashchange", watchLocation);
  window.addEventListener("popstate", watchLocation);
  setInterval(watchLocation, 1e3);
  watchLocation();
})();
//# sourceMappingURL=content.js.map
