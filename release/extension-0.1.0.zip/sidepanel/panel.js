"use strict";
(() => {
  // src/shared/context.ts
  var GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function parseContext(href) {
    const parts = routeParts(href);
    if (!parts) return null;
    for (const [blade, section, key, kind] of [
      ["GroupDetailsMenuBlade", "Members", "groupId", "group"],
      ["UserProfileMenuBlade", "Groups", "userId", "user"]
    ]) {
      const bladeIndex = parts.findIndex(
        (part) => part.toLowerCase() === blade.toLowerCase()
      );
      if (bladeIndex < 0 || parts[bladeIndex + 1] !== "~" || parts[bladeIndex + 2]?.toLowerCase() !== section.toLowerCase())
        continue;
      const keyIndex = parts.findIndex(
        (part, index) => index > bladeIndex + 2 && part.toLowerCase() === key.toLowerCase()
      );
      const id = parts[keyIndex + 1];
      if (keyIndex >= 0 && id && GUID.test(id))
        return { kind, id: id.toLowerCase() };
    }
    return null;
  }
  function routeParts(href) {
    let url;
    try {
      url = new URL(href);
    } catch {
      return null;
    }
    if (url.origin !== "https://entra.microsoft.com") return null;
    let hash = url.hash;
    for (let depth = 0; depth < 4; depth++) {
      try {
        const decoded = decodeURIComponent(hash);
        if (decoded === hash) break;
        hash = decoded;
      } catch {
        return null;
      }
    }
    return hash.replace(/^#/, "").split("/");
  }

  // src/shared/audit.ts
  function propertyId(value) {
    if (!value) return null;
    try {
      const decoded = JSON.parse(value);
      return typeof decoded === "string" ? decoded.toLowerCase() : null;
    } catch {
      return value.toLowerCase();
    }
  }
  function matchAudit(events, groupId, memberId) {
    const group = groupId.toLowerCase();
    const member = memberId.toLowerCase();
    const matches = events.filter((event2) => {
      if (event2.activityDisplayName !== "Add member to group" || event2.result !== "success" || !event2.activityDateTime || !Number.isFinite(Date.parse(event2.activityDateTime)))
        return false;
      const targets = event2.targetResources ?? [];
      const hasMember = targets.some(
        (target) => target.id?.toLowerCase() === member
      );
      const hasGroup = targets.some(
        (target) => target.id?.toLowerCase() === group || target.modifiedProperties?.some(
          (property) => property.displayName?.toLowerCase() === "group.objectid" && propertyId(property.newValue) === group
        )
      );
      return hasMember && hasGroup;
    });
    matches.sort(
      (left, right) => Date.parse(right.activityDateTime ?? "") - Date.parse(left.activityDateTime ?? "")
    );
    const event = matches[0];
    if (!event?.activityDateTime) return null;
    const app = event.initiatedBy?.app;
    const actor = event.initiatedBy?.user?.userPrincipalName ?? event.initiatedBy?.user?.displayName ?? app?.displayName ?? "Unknown actor";
    return {
      actor,
      when: event.activityDateTime,
      historicalPackage: !!app && (/entitlement management|identity governance/i.test(
        app.displayName ?? ""
      ) || app.appId?.toLowerCase() === "810dcf14-1858-4bf2-8134-4c369fa3235b")
    };
  }

  // src/shared/graph.ts
  var ROOT = "https://graph.microsoft.com/v1.0";
  var GraphError = class extends Error {
    constructor(status2, code, scope) {
      super(
        status2 === 401 ? "Your session expired. Sign in again." : status2 === 403 ? `Missing permission or directory role: ${scope}. Grant admin consent and verify your directory role.` : `Microsoft Graph request failed (${status2}, ${code}).`
      );
      this.status = status2;
      this.code = code;
      this.scope = scope;
      this.name = "GraphError";
    }
    status;
    code;
    scope;
  };
  function graphUrl(path) {
    const url = new URL(path.startsWith("/") ? `${ROOT}${path}` : path);
    if (url.origin !== "https://graph.microsoft.com" || !url.pathname.startsWith("/v1.0/") || url.username || url.password || url.hash)
      throw new Error("Rejected a Graph URL outside the Graph v1.0 endpoint.");
    return url.href;
  }
  function retryDelay(value, attempt, now = Date.now()) {
    let delay = Math.min(1e3 * 2 ** attempt, 3e4);
    if (value) {
      const seconds = Number(value);
      if (Number.isFinite(seconds) && seconds >= 0) delay = seconds * 1e3;
      else {
        const date = Date.parse(value);
        if (Number.isFinite(date)) delay = Math.max(0, date - now);
      }
    }
    if (delay > 6e4)
      throw new Error(
        "Microsoft Graph throttling requires a wait longer than 60 seconds. Try again later."
      );
    return delay;
  }
  function createGraphClient(getToken, fetcher = fetch, sleep = (ms, signal) => new Promise((resolve, reject) => {
    signal?.throwIfAborted();
    const onAbort = () => {
      clearTimeout(timer);
      reject(signal?.reason);
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  })) {
    async function graphFetch(path, scope, signal) {
      const url = graphUrl(path);
      signal?.throwIfAborted();
      let refreshed = false;
      let token = await getToken(false);
      let retries = 0;
      while (true) {
        signal?.throwIfAborted();
        const response = await fetcher(url, {
          headers: {
            Authorization: `Bearer ${token}`,
            ...new URL(url).pathname.includes("/microsoft.graph.") ? { ConsistencyLevel: "eventual" } : {}
          },
          redirect: "error",
          ...signal ? { signal } : {}
        });
        if (response.status === 401 && !refreshed) {
          refreshed = true;
          token = await getToken(true);
          continue;
        }
        if ((response.status === 429 || response.status === 503) && retries < 4) {
          await sleep(
            retryDelay(response.headers.get("Retry-After"), retries++),
            signal
          );
          continue;
        }
        if (!response.ok) {
          const body = await response.json().catch(() => null);
          const code = body && typeof body === "object" && "error" in body && body.error && typeof body.error === "object" && "code" in body.error && typeof body.error.code === "string" ? body.error.code : "RequestFailed";
          throw new GraphError(response.status, code, scope);
        }
        return await response.json();
      }
    }
    async function list(path, scope, signal) {
      const values = [];
      const visited = /* @__PURE__ */ new Set();
      let next = path;
      while (next) {
        const url = graphUrl(next);
        if (visited.has(url))
          throw new Error("Microsoft Graph returned a paging loop.");
        visited.add(url);
        const page = await graphFetch(url, scope, signal);
        if (!Array.isArray(page.value) || page["@odata.nextLink"] !== void 0 && typeof page["@odata.nextLink"] !== "string")
          throw new Error("Microsoft Graph returned an invalid list response.");
        values.push(...page.value);
        next = page["@odata.nextLink"];
      }
      return values;
    }
    return { graphFetch, list };
  }

  // src/shared/links.ts
  var PORTAL = "https://entra.microsoft.com/#view/";
  function packageLink(id) {
    return `${PORTAL}Microsoft_Azure_ELMAdmin/EntitlementMenuBlade/~/overview/entitlementId/${encodeURIComponent(id)}`;
  }
  function memberLink(kind, id) {
    return kind === "group" ? `${PORTAL}Microsoft_AAD_IAM/GroupDetailsMenuBlade/~/Overview/groupId/${encodeURIComponent(id)}` : `${PORTAL}Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/${encodeURIComponent(id)}`;
  }

  // src/shared/messages.ts
  async function request(type, payload) {
    const response = await chrome.runtime.sendMessage({
      type,
      payload
    });
    if (!response?.ok)
      throw new Error(
        response?.error ?? "The extension background worker is unavailable."
      );
    return response.value;
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : "An unexpected extension error occurred.";
  }

  // src/shared/settings.ts
  function validateSettings(value) {
    if (!value || typeof value !== "object" || !("tenantId" in value) || typeof value.tenantId !== "string" || !GUID.test(value.tenantId.trim()) || !("clientId" in value) || typeof value.clientId !== "string" || !GUID.test(value.clientId.trim()) || !("auditEnabled" in value) || typeof value.auditEnabled !== "boolean")
      throw new Error(
        "Configure valid tenant and client GUIDs in Options first."
      );
    return {
      tenantId: value.tenantId.trim().toLowerCase(),
      clientId: value.clientId.trim().toLowerCase(),
      auditEnabled: value.auditEnabled
    };
  }
  async function readSettings() {
    const stored = await chrome.storage.sync.get("settings");
    return validateSettings(stored.settings);
  }

  // src/shared/governance.ts
  var sameId = (left, right) => left?.toLowerCase() === right.toLowerCase();
  var ACTIVE_ASSIGNMENT_STATES = [
    "delivered",
    "partiallyDelivered",
    "delivering"
  ];
  function isActiveAssignment(state) {
    return ACTIVE_ASSIGNMENT_STATES.some((active) => active === state);
  }
  function packageContainsGroup(pkg, groupId) {
    return pkg.resourceRoleScopes?.some(
      ({ role, scope }) => scope?.originSystem === "AadGroup" && sameId(scope.originId, groupId) && (role?.originId?.startsWith("Member_") === true || role?.displayName === "Member")
    ) ?? false;
  }
  function classifyGovernance(group, memberId, packages, assignments) {
    const grants = [];
    for (const pkg of packages) {
      if (!packageContainsGroup(pkg, group.id)) continue;
      for (const assignment of assignments) {
        if (!isActiveAssignment(assignment.state) || !sameId(assignment.target?.objectId, memberId) || !sameId(assignment.accessPackage?.id, pkg.id))
          continue;
        const expiration = assignment.schedule?.expiration;
        grants.push({
          id: pkg.id,
          name: pkg.displayName,
          assignmentId: assignment.id,
          expiresAt: expiration?.endDateTime ?? null,
          duration: expiration?.type === "afterDuration" ? expiration.duration ?? null : null,
          startsAt: assignment.schedule?.startDateTime ?? null
        });
      }
    }
    if (grants.length) return { source: "access-package", packages: grants };
    if (group.groupTypes?.includes("DynamicMembership"))
      return {
        source: "dynamic",
        rule: group.membershipRule ?? "Rule unavailable"
      };
    if (group.onPremisesSyncEnabled) return { source: "synced" };
    return { source: "manual" };
  }

  // src/shared/packages.ts
  var ENTITLEMENTS = "/identityGovernance/entitlementManagement";
  var PACKAGE_SCOPE = "EntitlementManagement.Read.All";
  async function loadPackages(graph2, sessionId, signal) {
    const stored = await chrome.storage.session.get("packageCache");
    const cache = stored.packageCache;
    if (cache?.sessionId === sessionId && cache.expiresAt > Date.now())
      return cache.packages;
    const packages = await graph2.list(
      `${ENTITLEMENTS}/accessPackages?$expand=resourceRoleScopes($expand=role,scope)&$select=id,displayName`,
      PACKAGE_SCOPE,
      signal
    );
    const complete = await mapLimited(packages, 4, async (pkg) => {
      if (!pkg["resourceRoleScopes@odata.nextLink"]) return pkg;
      return {
        ...pkg,
        resourceRoleScopes: await graph2.list(
          `${ENTITLEMENTS}/accessPackages/${encodeURIComponent(pkg.id)}/resourceRoleScopes?$expand=role,scope`,
          PACKAGE_SCOPE,
          signal
        )
      };
    });
    signal.throwIfAborted();
    const auth = await chrome.storage.session.get("auth");
    const current = auth.auth;
    if (current?.sessionId === sessionId) {
      try {
        await chrome.storage.session.set({
          packageCache: {
            sessionId,
            expiresAt: Date.now() + 15 * 6e4,
            packages: complete
          }
        });
      } catch {
        console.warn(
          "Access package cache could not be saved to session storage."
        );
      }
    }
    return complete;
  }
  async function mapLimited(items, concurrency, operation) {
    if (!Number.isInteger(concurrency) || concurrency < 1)
      throw new Error("Concurrency must be a positive integer.");
    const results = new Array(items.length);
    const pending = items.entries();
    await Promise.all(
      Array.from({ length: Math.min(concurrency, items.length) }, async () => {
        for (const [index, item] of pending) {
          results[index] = await operation(item);
        }
      })
    );
    return results;
  }

  // src/sidepanel/data.ts
  var GROUP_SELECT = "id,displayName,groupTypes,membershipRule,onPremisesSyncEnabled";
  var GROUP_SCOPE = "GroupMember.Read.All";
  async function loadMembership(context2, graph2, sessionId, signal) {
    const packages = await loadPackages(graph2, sessionId, signal);
    if (context2.kind === "group") {
      const [group, members] = await Promise.all([
        graph2.graphFetch(
          `/groups/${context2.id}?$select=${GROUP_SELECT}`,
          GROUP_SCOPE,
          signal
        ),
        graph2.list(
          `/groups/${context2.id}/members?$select=id,displayName,userPrincipalName,mail&$top=999`,
          GROUP_SCOPE,
          signal
        )
      ]);
      const assignmentLists = await mapLimited(
        packages.filter((pkg) => packageContainsGroup(pkg, group.id)),
        4,
        async (pkg) => {
          const assignments3 = await graph2.list(
            `${ENTITLEMENTS}/assignments?$filter=${encodeURIComponent(`accessPackage/id eq '${pkg.id}'`)}&$expand=target&$select=id,state,schedule`,
            PACKAGE_SCOPE,
            signal
          );
          return assignments3.map((assignment) => ({
            ...assignment,
            accessPackage: { id: pkg.id }
          }));
        }
      );
      const assignments2 = assignmentLists.flat();
      return {
        title: `${group.displayName ?? group.id} - Members`,
        rows: members.map((member) => ({
          member,
          group,
          governance: classifyGovernance(group, member.id, packages, assignments2)
        }))
      };
    }
    const [profile, groups, assignments] = await Promise.all([
      // Reading another user's profile needs User.ReadBasic.All, which is not
      // requested, so the name is optional and the title falls back to the id.
      graph2.graphFetch(
        `/users/${context2.id}?$select=displayName,userPrincipalName`,
        GROUP_SCOPE,
        signal
      ).catch((error) => {
        if (signal.aborted) throw error;
        return null;
      }),
      graph2.list(
        `/users/${context2.id}/memberOf/microsoft.graph.group?$select=${GROUP_SELECT}&$count=true`,
        GROUP_SCOPE,
        signal
      ),
      graph2.list(
        `${ENTITLEMENTS}/assignments?$filter=${encodeURIComponent(`target/objectId eq '${context2.id}'`)}&$expand=accessPackage&$select=id,state,schedule`,
        PACKAGE_SCOPE,
        signal
      )
    ]);
    const user = { ...profile ?? {}, id: context2.id };
    const targeted = assignments.map((assignment) => ({
      ...assignment,
      target: { objectId: context2.id }
    }));
    return {
      title: `${user.displayName ?? user.userPrincipalName ?? user.id} - Groups`,
      rows: groups.map((group) => ({
        member: user,
        group,
        governance: classifyGovernance(group, context2.id, packages, targeted)
      }))
    };
  }

  // src/sidepanel/panel.ts
  function element(id, type) {
    const node = document.getElementById(id);
    if (!(node instanceof type)) throw new Error(`Missing panel element: ${id}`);
    return node;
  }
  var status = element("status", HTMLParagraphElement);
  var title = element("title", HTMLHeadingElement);
  var rowsElement = element("rows", HTMLUListElement);
  var filter = element("filter", HTMLSelectElement);
  var count = element("count", HTMLParagraphElement);
  var signIn = element("signin", HTMLButtonElement);
  var signOut = element("signout", HTMLButtonElement);
  var refresh = element("refresh", HTMLButtonElement);
  var graph = createGraphClient(
    (force) => request("getToken", { refresh: force })
  );
  var context = null;
  var activeTabId;
  var contextVersion = 0;
  var rows = [];
  var controller = new AbortController();
  var version = 0;
  var auditEnabled = false;
  var auditRunning = 0;
  var auditQueue = [];
  var observer;
  var auditResults = /* @__PURE__ */ new Map();
  function setStatus(text, error = false) {
    status.textContent = text;
    status.classList.toggle("error", error);
    status.setAttribute("role", error ? "alert" : "status");
  }
  function appendText(parent, text) {
    const paragraph = document.createElement("p");
    paragraph.textContent = text;
    parent.append(paragraph);
  }
  function link(text, href) {
    const anchor = document.createElement("a");
    anchor.textContent = text;
    anchor.href = href;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    return anchor;
  }
  function drainAudits() {
    while (auditRunning < 4 && auditQueue.length) {
      const operation = auditQueue.shift();
      if (!operation) break;
      auditRunning++;
      void operation().finally(() => {
        auditRunning--;
        drainAudits();
      });
    }
  }
  function auditControls(row, container) {
    const detail = document.createElement("p");
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Look up who added this";
    detail.textContent = auditEnabled ? "Audit history not yet loaded." : "Audit lookup disabled. Enable AuditLog.Read.All in Options to look up who added this.";
    button.hidden = !auditEnabled;
    container.append(detail, button);
    let started = false;
    const signal = controller.signal;
    const rowVersion = version;
    const key = `${row.group.id}:${row.member.id}`;
    const cached = auditResults.get(key);
    if (cached) {
      detail.textContent = cached;
      button.hidden = true;
      started = true;
    }
    function lookup() {
      if (started || signal.aborted || rowVersion !== version || !auditEnabled)
        return;
      started = true;
      detail.classList.remove("error");
      button.disabled = true;
      detail.textContent = "Waiting for audit lookup...";
      auditQueue.push(async () => {
        if (signal.aborted) return;
        try {
          detail.textContent = "Looking up audit history...";
          const events = await graph.list(
            `/auditLogs/directoryAudits?$filter=${encodeURIComponent(`activityDisplayName eq 'Add member to group' and targetResources/any(t:t/id eq '${row.member.id}')`)}&$orderby=activityDateTime desc&$top=50`,
            "AuditLog.Read.All",
            signal
          );
          if (rowVersion !== version || signal.aborted) return;
          const attribution = matchAudit(events, row.group.id, row.member.id);
          detail.textContent = attribution ? `${attribution.historicalPackage ? "Access package (historical). " : ""}Added by: ${attribution.actor}, ${new Date(attribution.when).toLocaleString()}.` : "Added by: unknown (older than audit retention, or no matching successful event retained).";
          auditResults.set(key, detail.textContent);
          button.hidden = true;
        } catch (error) {
          if (signal.aborted || rowVersion !== version) return;
          detail.textContent = errorMessage(error);
          detail.classList.add("error");
          button.textContent = "Retry audit lookup";
          button.disabled = false;
          started = false;
          if (error instanceof GraphError && error.status === 401) {
            setStatus(error.message, true);
            signIn.hidden = false;
          }
        }
      });
      drainAudits();
    }
    button.addEventListener("click", lookup);
    return lookup;
  }
  function renderRows() {
    observer?.disconnect();
    rowsElement.replaceChildren();
    const visible = rows.filter(
      (row) => filter.value === "all" || row.governance.source === filter.value
    );
    count.textContent = `${visible.length} of ${rows.length} direct memberships`;
    const lookups = /* @__PURE__ */ new Map();
    observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          lookups.get(entry.target)?.();
          observer?.unobserve(entry.target);
        }
      },
      { rootMargin: "100px" }
    );
    for (const row of visible) {
      const item = document.createElement("li");
      item.className = "row";
      const subject = context?.kind === "user" ? row.group : row.member;
      const kind = context?.kind === "user" || subject["@odata.type"] === "#microsoft.graph.group" ? "group" : "user";
      const name = subject.displayName ?? subject.userPrincipalName ?? subject.id;
      if (context?.kind === "user" || !subject["@odata.type"] || subject["@odata.type"] === "#microsoft.graph.user" || subject["@odata.type"] === "#microsoft.graph.group")
        item.append(link(name, memberLink(kind, subject.id)));
      else {
        appendText(item, name);
        item.append(link("Open group", memberLink("group", row.group.id)));
      }
      if (subject.userPrincipalName) appendText(item, subject.userPrincipalName);
      const badge = document.createElement("span");
      badge.className = "badge";
      const governance = row.governance;
      badge.textContent = {
        "access-package": "Access package",
        dynamic: "Dynamic",
        synced: "Synced (AD)",
        manual: "Manual"
      }[governance.source];
      item.append(document.createElement("br"), badge);
      if (governance.source === "access-package") {
        const byPackage = /* @__PURE__ */ new Map();
        for (const grant of governance.packages) {
          const grants = byPackage.get(grant.id) ?? [];
          grants.push(grant);
          byPackage.set(grant.id, grants);
        }
        for (const grants of byPackage.values()) {
          const first = grants[0];
          if (!first) continue;
          const paragraph = document.createElement("p");
          paragraph.append(link(first.name, packageLink(first.id)));
          for (const grant of grants) {
            const expiry = grant.expiresAt ? ` - expires ${new Date(grant.expiresAt).toLocaleString()}` : grant.duration ? ` - expires after ${grant.duration}${grant.startsAt ? ` from ${new Date(grant.startsAt).toLocaleString()}` : ""}` : " - no fixed expiry returned";
            paragraph.append(document.createTextNode(expiry));
          }
          item.append(paragraph);
        }
      } else if (governance.source === "dynamic")
        appendText(item, governance.rule);
      else if (governance.source === "manual") {
        const lookup = auditControls(row, item);
        if (auditEnabled) lookups.set(item, lookup);
      }
      rowsElement.append(item);
      if (lookups.has(item)) observer.observe(item);
    }
  }
  async function reload() {
    controller.abort();
    controller = new AbortController();
    const signal = controller.signal;
    const loadVersion = ++version;
    auditQueue.length = 0;
    auditResults.clear();
    observer?.disconnect();
    rows = [];
    rowsElement.replaceChildren();
    title.textContent = "";
    count.textContent = "";
    refresh.disabled = true;
    try {
      const auth = await request("authStatus", void 0);
      if (loadVersion !== version) return;
      signIn.hidden = auth.signedIn;
      signOut.hidden = !auth.signedIn;
      if (!auth.signedIn || !auth.sessionId) {
        setStatus(
          "Set your tenant and client IDs in Options, then sign in to Microsoft Entra."
        );
        return;
      }
      if (!context) {
        setStatus(
          "Open Group > Members or User > Groups in the Entra admin center."
        );
        return;
      }
      const settings = await readSettings();
      if (loadVersion !== version || signal.aborted) return;
      auditEnabled = settings.auditEnabled;
      setStatus("Loading direct memberships and access package governance...");
      const data = await loadMembership(context, graph, auth.sessionId, signal);
      if (loadVersion !== version || signal.aborted) return;
      title.textContent = data.title;
      rows = data.rows;
      renderRows();
      setStatus(
        rows.length ? "Memberships loaded. Audit lookups run lazily for visible manual rows." : "No direct memberships found."
      );
    } catch (error) {
      if (loadVersion !== version || signal.aborted) return;
      controller.abort();
      setStatus(errorMessage(error), true);
      signIn.hidden = false;
    } finally {
      if (loadVersion === version) refresh.disabled = false;
    }
  }
  async function updateContext() {
    const queryVersion = ++contextVersion;
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      if (queryVersion !== contextVersion) return;
      const next = parseContext(tab?.url ?? "");
      if (activeTabId !== tab?.id || next?.kind !== context?.kind || next?.id !== context?.id) {
        activeTabId = tab?.id;
        context = next;
        await reload();
      }
    } catch (error) {
      setStatus(errorMessage(error), true);
    }
  }
  async function authentication(action) {
    const button = action === "signIn" ? signIn : signOut;
    button.disabled = true;
    setStatus(
      action === "signIn" ? "Complete sign-in in the Microsoft window..." : "Signing out..."
    );
    try {
      await request(action, void 0);
      await reload();
    } catch (error) {
      setStatus(errorMessage(error), true);
    } finally {
      button.disabled = false;
    }
  }
  signIn.addEventListener("click", () => void authentication("signIn"));
  signOut.addEventListener("click", () => void authentication("signOut"));
  refresh.addEventListener("click", () => void reload());
  filter.addEventListener("change", renderRows);
  element("options", HTMLButtonElement).addEventListener("click", () => {
    void chrome.runtime.openOptionsPage().catch((error) => setStatus(errorMessage(error), true));
  });
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (sender.id === chrome.runtime.id && sender.tab?.id === activeTabId && message && typeof message === "object" && "type" in message && message.type === "contextChanged")
      void updateContext();
  });
  chrome.tabs.onActivated.addListener(() => void updateContext());
  chrome.tabs.onUpdated.addListener((id, change) => {
    if (id === activeTabId && change.url) void updateContext();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.settings) void reload();
    if (area === "session" && changes.auth) {
      const before = changes.auth.oldValue;
      const after = changes.auth.newValue;
      if (before?.sessionId !== after?.sessionId) void reload();
    }
  });
  void updateContext().then(() => {
    if (activeTabId === void 0) return reload();
  });
})();
//# sourceMappingURL=panel.js.map
